#include <stdio.h>

int main(){
      int N;
      scanf("%d", &N);

      N % 2 == 0 ? printf("Par\n") : printf("Impar\n");

      return 0;
}