#include <stdio.h>

int main(){
      int A, B, C;
      scanf("%d %d %d", &A, &B, &C);

      if(A+B < C){
            printf("A soma de A + B e menor que C.\n");
      }

      return 0;
}